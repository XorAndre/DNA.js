//Menu
const itens =[
    {link: 'Home',  endereco: 'index.html'},
    {link: 'Sobre-Dev',  endereco: 'dev.html'},
    {link: 'Serviços',  endereco: 'servicos.html'},
    {link: 'Portfólio',  endereco: 'portfolio.html'},
    {link: 'Contato',  endereco: 'contato.html'},
    {link: 'Blog',  endereco: 'blog.html'},
]; 
dna.clone('itens', itens);